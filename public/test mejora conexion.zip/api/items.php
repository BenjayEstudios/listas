<?php
header("Content-Type: application/json");
if (in_array($_SERVER['HTTP_HOST'], ['localhost', '127.0.0.1'])) {
    // Entorno de desarrollo local
    require_once '../config/db.php';
} else {
    // Entorno de producción (benjayapps.cl)
    require_once '../../../db.php';
}


$method = $_SERVER['REQUEST_METHOD'];

try {
    switch($method) {
        case 'GET':
            // Obtener ítems de una lista: api/items.php?lista_id=1
            $lista_id = $_GET['lista_id'] ?? null;
            if (!$lista_id) throw new Exception("ID de lista requerido");

            $stmt = $pdo->prepare("SELECT * FROM items_lista WHERE lista_id = ? ORDER BY created_at DESC");
            $stmt->execute([$lista_id]);
            echo json_encode($stmt->fetchAll());
            break;

        case 'POST':
            // Añadir ítem a una lista
            $data = json_decode(file_get_contents('php://input'), true);
            if (!empty($data['contenido']) && !empty($data['lista_id'])) {
                $stmt = $pdo->prepare("INSERT INTO items_lista (lista_id, contenido) VALUES (?, ?)");
                $stmt->execute([$data['lista_id'], $data['contenido']]);
                echo json_encode(["success" => true, "id" => $pdo->lastInsertId()]);
            }
            break;

        // Dentro del switch($method) en api/items.php
        case 'PUT':
            $data = json_decode(file_get_contents('php://input'), true);
            if (empty($data['id'])) throw new Exception("ID faltante");

            if (isset($data['op']) && $data['op'] === 'update_text') {
                // Actualiza contenido y etiqueta en la misma consulta
                $stmt = $pdo->prepare("UPDATE items_lista SET contenido = ?, etiqueta = ? WHERE id = ?");
                $stmt->execute([$data['contenido'], $data['etiqueta'] ?? null, $data['id']]);
            } else {
                $stmt = $pdo->prepare("UPDATE items_lista SET completado = ? WHERE id = ?");
                $stmt->execute([$data['completado'], $data['id']]);
            }
            echo json_encode(["success" => true]);
            break;

        case 'DELETE':
            $data = json_decode(file_get_contents('php://input'), true);
            if (!empty($data['id'])) {
                $stmt = $pdo->prepare("DELETE FROM items_lista WHERE id = ?");
                $stmt->execute([$data['id']]);
                echo json_encode(["success" => true]);
            }
            break;
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["error" => $e->getMessage()]);
}